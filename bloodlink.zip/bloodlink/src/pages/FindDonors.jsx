import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { SearchX, UserPlus, Users } from 'lucide-react';
import DonorCard from '../components/DonorCard';
import SearchFilters from '../components/SearchFilters';
import { useApp } from '../context/AppContext';
import { BLOOD_GROUPS } from '../utils/helpers';

const DEFAULT_FILTERS = { group: 'All', city: 'All', availability: 'All' };

export default function FindDonors() {
  const { donors } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [applied, setApplied] = useState(DEFAULT_FILTERS);

  // Pre-apply a blood group when arriving from the home page cards (?group=O+).
  useEffect(() => {
    const group = searchParams.get('group');
    if (group && BLOOD_GROUPS.includes(group)) {
      const next = { ...DEFAULT_FILTERS, group };
      setFilters(next);
      setApplied(next);
    }
  }, [searchParams]);

  const cities = useMemo(
    () => [...new Set(donors.map((donor) => donor.city.trim()))].sort(),
    [donors]
  );

  const results = useMemo(
    () =>
      donors.filter((donor) => {
        if (applied.group !== 'All' && donor.bloodGroup !== applied.group) return false;
        if (
          applied.city !== 'All' &&
          donor.city.trim().toLowerCase() !== applied.city.toLowerCase()
        ) {
          return false;
        }
        if (applied.availability === 'Available' && !donor.available) return false;
        if (applied.availability === 'Unavailable' && donor.available) return false;
        return true;
      }),
    [donors, applied]
  );

  const handleReset = () => {
    setFilters(DEFAULT_FILTERS);
    setApplied(DEFAULT_FILTERS);
    setSearchParams({});
  };

  return (
    <div>
      {/* Page header */}
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page py-12">
          <p className="page-eyebrow">Donor directory</p>
          <h1 className="page-title">Find Donors</h1>
          <p className="mt-3 max-w-2xl text-slate-600">
            Search voluntary donors by blood group, city, and availability, then reach out
            directly.
          </p>
        </div>
      </section>

      <section className="container-page py-10">
        <SearchFilters
          filters={filters}
          onChange={setFilters}
          onSearch={() => setApplied(filters)}
          onReset={handleReset}
          cities={cities}
        />

        <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
          <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">
            <Users className="h-4 w-4 text-red-600" />
            {results.length} donor{results.length === 1 ? '' : 's'} found
          </p>
          <Link to="/become-donor" className="btn-ghost text-xs">
            <UserPlus className="h-4 w-4" />
            Become a donor
          </Link>
        </div>

        {results.length > 0 ? (
          <div className="mt-5 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {results.map((donor, index) => (
              <div
                key={donor.id}
                className="animate-fade-up"
                style={{ animationDelay: `${Math.min(index, 8) * 50}ms` }}
              >
                <DonorCard donor={donor} />
              </div>
            ))}
          </div>
        ) : (
          <div className="card mt-5 flex flex-col items-center gap-3 p-12 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 text-slate-400">
              <SearchX className="h-7 w-7" />
            </span>
            <h2 className="font-display text-lg font-bold text-slate-900">
              No donors match these filters
            </h2>
            <p className="max-w-sm text-sm text-slate-500">
              Try a different blood group or city, or clear the filters to see every registered
              donor.
            </p>
            <button type="button" onClick={handleReset} className="btn-secondary mt-2">
              Clear filters
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
