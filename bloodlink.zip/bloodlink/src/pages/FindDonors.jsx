import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowUpDown, SearchX, UserPlus, Users } from 'lucide-react';
import DonorCard from '../components/DonorCard';
import SearchFilters from '../components/SearchFilters';
import { useApp } from '../context/AppContext';
import { BLOOD_GROUPS } from '../utils/helpers';

const DEFAULT_FILTERS = { group: 'All', city: 'All', availability: 'All' };

const SORT_OPTIONS = [
  { value: 'availability', label: 'Availability first' },
  { value: 'group', label: 'Blood group' },
  { value: 'name', label: 'Name (A–Z)' },
  { value: 'city', label: 'City (A–Z)' },
  { value: 'recent', label: 'Recent donation' },
];

export default function FindDonors() {
  const { donors } = useApp();
  const [searchParams, setSearchParams] = useSearchParams();
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [applied, setApplied] = useState(DEFAULT_FILTERS);
  const [sortBy, setSortBy] = useState('availability');

  // Pre-apply a blood group when arriving from the home page cards (?group=O+).
  useEffect(() => {
    const group = searchParams.get('group');
    if (group && BLOOD_GROUPS.includes(group)) {
      const next = { ...DEFAULT_FILTERS, group };
      setFilters(next);
      setApplied(next);
    }
  }, [searchParams]);

  const cities = useMemo(
    () => [...new Set(donors.map((donor) => donor.city.trim()))].sort(),
    [donors]
  );

  const results = useMemo(
    () =>
      donors.filter((donor) => {
        if (applied.group !== 'All' && donor.bloodGroup !== applied.group) return false;
        if (
          applied.city !== 'All' &&
          donor.city.trim().toLowerCase() !== applied.city.toLowerCase()
        ) {
          return false;
        }
        if (applied.availability === 'Available' && !donor.available) return false;
        if (applied.availability === 'Unavailable' && donor.available) return false;
        return true;
      }),
    [donors, applied]
  );

  // Sort the filtered results by the selected criterion.
  const sortedResults = useMemo(() => {
    const list = [...results];
    switch (sortBy) {
      case 'group':
        list.sort(
          (a, b) =>
            BLOOD_GROUPS.indexOf(a.bloodGroup) - BLOOD_GROUPS.indexOf(b.bloodGroup) ||
            a.name.localeCompare(b.name)
        );
        break;
      case 'name':
        list.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'city':
        list.sort((a, b) => a.city.localeCompare(b.city) || a.name.localeCompare(b.name));
        break;
      case 'recent':
        list.sort(
          (a, b) => new Date(b.lastDonation || 0) - new Date(a.lastDonation || 0)
        );
        break;
      default: // availability first
        list.sort((a, b) => b.available - a.available || a.name.localeCompare(b.name));
    }
    return list;
  }, [results, sortBy]);

  const handleReset = () => {
    setFilters(DEFAULT_FILTERS);
    setApplied(DEFAULT_FILTERS);
    setSearchParams({});
  };

  return (
    <div>
      {/* Page header */}
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page py-12">
          <p className="page-eyebrow">Donor directory</p>
          <h1 className="page-title">Find Donors</h1>
          <p className="mt-3 max-w-2xl text-slate-600">
            Search voluntary donors by blood group, city, and availability, then reach out
            directly.
          </p>
        </div>
      </section>

      <section className="container-page py-10">
        <SearchFilters
          filters={filters}
          onChange={setFilters}
          onSearch={() => setApplied(filters)}
          onReset={handleReset}
          cities={cities}
        />

        <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
          <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">
            <Users className="h-4 w-4 text-red-600" />
            {sortedResults.length} donor{sortedResults.length === 1 ? '' : 's'} found
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <label
              htmlFor="sort-donors"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-500"
            >
              <ArrowUpDown className="h-3.5 w-3.5" />
              Sort by
            </label>
            <select
              id="sort-donors"
              value={sortBy}
              onChange={(event) => setSortBy(event.target.value)}
              className="input-field w-auto py-2 text-xs"
            >
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
            <Link to="/become-donor" className="btn-ghost text-xs">
              <UserPlus className="h-4 w-4" />
              Become a donor
            </Link>
          </div>
        </div>

        {sortedResults.length > 0 ? (
          <div className="mt-5 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
            {sortedResults.map((donor, index) => (
              <div
                key={donor.id}
                className="animate-fade-up"
                style={{ animationDelay: `${Math.min(index, 8) * 50}ms` }}
              >
                <DonorCard donor={donor} />
              </div>
            ))}
          </div>
        ) : (
          <div className="card mt-5 flex flex-col items-center gap-3 p-12 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 text-slate-400">
              <SearchX className="h-7 w-7" />
            </span>
            <h2 className="font-display text-lg font-bold text-slate-900">
              No donors match these filters
            </h2>
            <p className="max-w-sm text-sm text-slate-500">
              Try a different blood group or city, or clear the filters to see every registered
              donor.
            </p>
            <button type="button" onClick={handleReset} className="btn-secondary mt-2">
              Clear filters
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
