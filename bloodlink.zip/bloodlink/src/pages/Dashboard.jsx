import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  Activity,
  BarChart3,
  CheckCircle2,
  ClipboardList,
  HeartHandshake,
  RefreshCw,
  UserCheck,
  Users,
} from 'lucide-react';
import StatCard from '../components/StatCard';
import { useApp } from '../context/AppContext';
import { BLOOD_GROUPS, cx, URGENCY_STYLES } from '../utils/helpers';

export default function Dashboard() {
  const { donors, requests, markRequestCompleted, resetDemoData, toast } = useApp();

  const stats = useMemo(
    () => ({
      totalDonors: donors.length,
      availableDonors: donors.filter((donor) => donor.available).length,
      activeRequests: requests.filter((request) => request.status === 'Active').length,
      completed: requests.filter((request) => request.status === 'Completed').length,
    }),
    [donors, requests]
  );

  const recentRequests = useMemo(
    () =>
      [...requests]
        .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        .slice(0, 8),
    [requests]
  );

  const groupCounts = useMemo(
    () =>
      BLOOD_GROUPS.map((group) => ({
        group,
        count: donors.filter((donor) => donor.bloodGroup === group).length,
      })),
    [donors]
  );
  const maxCount = Math.max(1, ...groupCounts.map((entry) => entry.count));

  const handleComplete = (id) => {
    markRequestCompleted(id);
    toast('Request marked as completed.');
  };

  const handleReset = () => {
    const confirmed = window.confirm(
      'Reset all demo data? Donors and requests added in this browser will be replaced with the original sample data.'
    );
    if (confirmed) {
      resetDemoData();
      toast('Demo data has been reset.', 'info');
    }
  };

  return (
    <div>
      {/* Page header */}
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page flex flex-col gap-6 py-12 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="page-eyebrow">Overview</p>
            <h1 className="page-title">Dashboard</h1>
            <p className="mt-3 max-w-2xl text-slate-600">
              A live snapshot of the network in this browser.
            </p>
          </div>
          <button type="button" onClick={handleReset} className="btn-secondary shrink-0">
            <RefreshCw className="h-4 w-4" />
            Reset Demo Data
          </button>
        </div>
      </section>

      <section className="container-page space-y-8 py-10">
        {/* Stat cards */}
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <StatCard variant="light" icon={Users} value={stats.totalDonors} label="Total Donors" />
          <StatCard
            variant="light"
            icon={UserCheck}
            value={stats.availableDonors}
            label="Available Donors"
          />
          <StatCard
            variant="light"
            icon={Activity}
            value={stats.activeRequests}
            label="Emergency Requests"
          />
          <StatCard
            variant="light"
            icon={HeartHandshake}
            value={stats.completed}
            label="Successful Connections"
          />
        </div>

        <div className="grid gap-8 lg:grid-cols-5">
          {/* Recent requests table */}
          <div className="card overflow-hidden lg:col-span-3">
            <div className="flex items-center justify-between border-b border-slate-200 p-5">
              <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <ClipboardList className="h-4 w-4 text-red-600" />
                Recent Emergency Requests
              </p>
              <Link
                to="/emergency-requests"
                className="text-xs font-semibold text-red-600 hover:underline"
              >
                View all
              </Link>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[560px] text-left text-sm">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-xs uppercase tracking-wider text-slate-500">
                    <th className="px-5 py-3 font-semibold">Requester</th>
                    <th className="px-5 py-3 font-semibold">Blood Group</th>
                    <th className="px-5 py-3 font-semibold">Hospital</th>
                    <th className="px-5 py-3 font-semibold">City</th>
                    <th className="px-5 py-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentRequests.map((request) => (
                    <tr
                      key={request.id}
                      className="border-b border-slate-100 last:border-0 hover:bg-slate-50/60"
                    >
                      <td className="px-5 py-3.5 font-medium text-slate-900">
                        {request.patientName}
                      </td>
                      <td className="px-5 py-3.5">
                        <span className="inline-flex h-8 w-10 items-center justify-center rounded-lg bg-red-50 font-display text-xs font-extrabold text-red-700">
                          {request.bloodGroup}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-slate-600">{request.hospital}</td>
                      <td className="px-5 py-3.5 text-slate-600">{request.city}</td>
                      <td className="px-5 py-3.5">
                        {request.status === 'Completed' ? (
                          <span className="badge border-emerald-200 bg-emerald-50 text-emerald-700">
                            <CheckCircle2 className="h-3 w-3" />
                            Completed
                          </span>
                        ) : (
                          <button
                            type="button"
                            onClick={() => handleComplete(request.id)}
                            title="Mark this request as completed"
                            className={cx(
                              'badge transition-colors hover:border-emerald-300 hover:bg-emerald-50 hover:text-emerald-700',
                              (URGENCY_STYLES[request.urgency] || URGENCY_STYLES.Normal).badge
                            )}
                          >
                            {request.urgency} · Mark done
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {recentRequests.length === 0 && (
                <p className="p-6 text-sm text-slate-500">
                  No requests yet. Create one from the Request Blood page.
                </p>
              )}
            </div>
          </div>

          {/* Donors by blood group */}
          <div className="card p-5 lg:col-span-2">
            <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <BarChart3 className="h-4 w-4 text-red-600" />
              Donors by Blood Group
            </p>
            <div className="mt-5 space-y-3.5">
              {groupCounts.map(({ group, count }) => (
                <div key={group} className="flex items-center gap-3">
                  <span className="w-9 shrink-0 font-display text-sm font-bold text-slate-900">
                    {group}
                  </span>
                  <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-slate-100">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-red-500 to-red-600 transition-all duration-500"
                      style={{ width: `${(count / maxCount) * 100}%` }}
                    />
                  </div>
                  <span className="w-6 shrink-0 text-right text-sm font-semibold text-slate-600">
                    {count}
                  </span>
                </div>
              ))}
            </div>
            <p className="mt-5 text-xs text-slate-400">
              Counts update live as new donors register.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
