export default function Privacy() {
  return (
    <div>
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page py-12">
          <p className="page-eyebrow">Privacy</p>
          <h1 className="page-title">Privacy Notes</h1>
        </div>
      </section>

      <section className="container-page py-10">
        <div className="card max-w-3xl space-y-4 p-6 leading-relaxed text-slate-600 sm:p-8">
          <p>
            BloodLink is a demonstration project and does not have a server. Everything you enter
            — donor registrations and emergency requests — is saved only in your own browser using
            localStorage. Nothing is uploaded or shared anywhere.
          </p>
          <p>
            All pre-loaded donors, requesters, phone numbers, emails, and hospitals are fictional
            sample data created for the demo. Please avoid entering real personal details while
            testing.
          </p>
          <p>
            You can clear all stored data at any time using the "Reset Demo Data" button on the
            Dashboard, or by clearing this site's data in your browser settings.
          </p>
        </div>
      </section>
    </div>
  );
}
