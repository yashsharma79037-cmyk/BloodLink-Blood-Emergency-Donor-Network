import { Link, useNavigate } from 'react-router-dom';
import { Activity, HeartHandshake, MapPin, UserPlus, Users } from 'lucide-react';
import Hero from '../components/Hero';
import StatCard from '../components/StatCard';
import BloodGroupCard from '../components/BloodGroupCard';
import SectionHeading from '../components/SectionHeading';
import { useApp } from '../context/AppContext';
import { BLOOD_GROUPS } from '../utils/helpers';

const STATS = [
  { icon: Users, value: 1250, suffix: '+', label: 'Registered Donors' },
  { icon: HeartHandshake, value: 340, suffix: '+', label: 'Lives Helped' },
  { icon: MapPin, value: 25, suffix: '+', label: 'Cities' },
  { icon: Activity, value: 45, suffix: '', label: 'Active Requests' },
];

export default function Home() {
  const { donors } = useApp();
  const navigate = useNavigate();

  const countByGroup = (group) => donors.filter((donor) => donor.bloodGroup === group).length;

  return (
    <div>
      <Hero />

      {/* Statistics band */}
      <section className="relative overflow-hidden bg-gradient-to-br from-red-600 to-red-700">
        <div
          className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-2xl"
          aria-hidden="true"
        />
        <div className="container-page py-14">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {STATS.map((stat) => (
              <StatCard key={stat.label} {...stat} variant="solid" />
            ))}
          </div>
          <p className="mt-6 text-center text-xs text-red-100/80">
            Sample statistics shown for demonstration purposes.
          </p>
        </div>
      </section>

      {/* Blood groups */}
      <section className="bg-slate-50">
        <div className="container-page py-16 sm:py-20">
          <SectionHeading
            center
            eyebrow="Blood groups"
            title="Search donors by blood group"
            subtitle="Select a group to instantly filter the donor directory."
          />
          <div className="mt-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
            {BLOOD_GROUPS.map((group) => (
              <BloodGroupCard
                key={group}
                group={group}
                count={countByGroup(group)}
                onClick={() => navigate(`/find-donors?group=${encodeURIComponent(group)}`)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Closing CTA */}
      <section className="bg-white">
        <div className="container-page py-16 sm:py-20">
          <div className="card flex flex-col items-center gap-5 p-8 text-center sm:p-12">
            <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-red-50 text-red-600">
              <UserPlus className="h-6 w-6" />
            </span>
            <div>
              <h2 className="font-display text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl">
                Every donor is someone's lifeline
              </h2>
              <p className="mx-auto mt-2 max-w-lg text-slate-600">
                Join the network as a voluntary donor and get discovered when a matching emergency
                appears in your city.
              </p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <Link to="/become-donor" className="btn-primary">
                Register as Donor
              </Link>
              <Link to="/emergency-requests" className="btn-secondary">
                View Emergency Requests
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
