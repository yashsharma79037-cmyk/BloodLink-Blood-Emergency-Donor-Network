import { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Droplet, HeartPulse, MapPin, ShieldCheck } from 'lucide-react';
import DonorForm from '../components/DonorForm';

const REASONS = [
  {
    icon: Droplet,
    title: 'One donation, up to three lives',
    text: 'A single unit can support multiple patients during emergencies.',
  },
  {
    icon: MapPin,
    title: 'Matched in your own city',
    text: 'Requesters in your city see you first when your blood group is needed.',
  },
  {
    icon: HeartPulse,
    title: 'You stay in control',
    text: 'Mark yourself available or unavailable — donors are only contacted directly.',
  },
];

export default function BecomeDonor() {
  const [registered, setRegistered] = useState(null);

  return (
    <div>
      {/* Page header */}
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page py-12">
          <p className="page-eyebrow">Join the network</p>
          <h1 className="page-title">Become a Donor</h1>
          <p className="mt-3 max-w-2xl text-slate-600">
            Register as a voluntary donor so people nearby can find you when they need your blood
            group.
          </p>
        </div>
      </section>

      <section className="container-page py-10">
        {!registered ? (
          <div className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <DonorForm onRegistered={setRegistered} />
            </div>

            <aside className="space-y-5">
              <div className="card p-6">
                <p className="text-sm font-semibold text-slate-900">Why register?</p>
                <div className="mt-4 space-y-4">
                  {REASONS.map((reason) => (
                    <div key={reason.title} className="flex items-start gap-3">
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                        <reason.icon className="h-4 w-4" />
                      </span>
                      <div>
                        <p className="text-sm font-semibold text-slate-900">{reason.title}</p>
                        <p className="mt-0.5 text-xs leading-relaxed text-slate-500">
                          {reason.text}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6 text-sm text-slate-600">
                <p className="flex items-center gap-2 font-semibold text-slate-900">
                  <ShieldCheck className="h-4 w-4 text-red-600" />
                  About eligibility
                </p>
                <p className="mt-2 text-xs leading-relaxed">
                  BloodLink never makes medical eligibility decisions. Final screening always
                  happens with qualified healthcare professionals at an authorized blood bank
                  before any donation.
                </p>
              </div>
            </aside>
          </div>
        ) : (
          <div className="card mx-auto max-w-2xl border-emerald-200 p-8 text-center">
            <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
              <CheckCircle2 className="h-7 w-7" />
            </span>
            <h2 className="mt-4 font-display text-2xl font-bold text-slate-900">
              Welcome to the network, {registered.name.split(' ')[0]}!
            </h2>
            <p className="mx-auto mt-2 max-w-md text-sm text-slate-600">
              You are now registered as a{' '}
              <span className="font-semibold text-slate-900">{registered.bloodGroup}</span> donor
              in <span className="font-semibold text-slate-900">{registered.city}</span> and will
              appear in donor search results.
            </p>
            <div className="mt-6 flex flex-col justify-center gap-3 sm:flex-row">
              <Link to="/find-donors" className="btn-primary">
                View Donor Directory
              </Link>
              <button
                type="button"
                onClick={() => setRegistered(null)}
                className="btn-secondary"
              >
                Register another donor
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
