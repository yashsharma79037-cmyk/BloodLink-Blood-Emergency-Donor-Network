import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, ClipboardList, Siren, Users } from 'lucide-react';
import DonorCard from '../components/DonorCard';
import RequestForm from '../components/RequestForm';
import { useApp } from '../context/AppContext';
import { findMatchingDonors } from '../utils/helpers';

const NEXT_STEPS = [
  'Your request appears instantly on the Emergency Requests board.',
  'Matching donors in your city are suggested right after you submit.',
  'Donors reach out to you directly on the contact number you provide.',
];

export default function RequestBlood() {
  const { donors, toast } = useApp();
  const [submitted, setSubmitted] = useState(null);
  const resultsRef = useRef(null);

  const matches = submitted
    ? findMatchingDonors(donors, submitted.bloodGroup, submitted.city)
    : null;

  const handleSubmitted = (request) => {
    setSubmitted(request);
    const found = findMatchingDonors(donors, request.bloodGroup, request.city);
    if (found.exact.length > 0) {
      toast(
        `${found.exact.length} matching donor${found.exact.length > 1 ? 's' : ''} found in ${request.city}.`,
        'info'
      );
    } else {
      toast(`No available ${request.bloodGroup} donors in ${request.city} yet.`, 'info');
    }
  };

  useEffect(() => {
    if (submitted && resultsRef.current) {
      resultsRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, [submitted]);

  return (
    <div>
      {/* Page header */}
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page py-12">
          <p className="page-eyebrow">Emergency form</p>
          <h1 className="page-title">Create Blood Request</h1>
          <p className="mt-3 max-w-2xl text-slate-600">
            Post an emergency request and get instantly matched with available donors of the same
            blood group in your city.
          </p>
        </div>
      </section>

      <section className="container-page py-10">
        {!submitted ? (
          <div className="grid gap-8 lg:grid-cols-3">
            <div className="lg:col-span-2">
              <RequestForm onSubmitted={handleSubmitted} />
            </div>

            <aside className="space-y-5">
              <div className="card p-6">
                <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                  <ClipboardList className="h-4 w-4 text-red-600" />
                  What happens next
                </p>
                <ol className="mt-4 space-y-3">
                  {NEXT_STEPS.map((step, index) => (
                    <li key={step} className="flex items-start gap-3 text-sm text-slate-600">
                      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-red-50 text-[11px] font-bold text-red-600">
                        {index + 1}
                      </span>
                      {step}
                    </li>
                  ))}
                </ol>
              </div>

              <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-sm text-red-900">
                <p className="flex items-center gap-2 font-semibold">
                  <Siren className="h-4 w-4" />
                  Medical emergency?
                </p>
                <p className="mt-2 leading-relaxed">
                  Contact your hospital's blood bank or local emergency services first. BloodLink
                  is a demo and does not replace professional emergency care.
                </p>
              </div>
            </aside>
          </div>
        ) : (
          <div ref={resultsRef} className="scroll-mt-24 space-y-10">
            {/* Success panel */}
            <div className="card border-emerald-200 p-6 sm:p-8">
              <div className="flex items-start gap-4">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                  <CheckCircle2 className="h-6 w-6" />
                </span>
                <div>
                  <h2 className="font-display text-xl font-bold text-slate-900">
                    Request submitted
                  </h2>
                  <p className="mt-1 text-sm text-slate-600">
                    Your request for{' '}
                    <span className="font-semibold text-slate-900">
                      {submitted.units} unit{submitted.units > 1 ? 's' : ''} of{' '}
                      {submitted.bloodGroup}
                    </span>{' '}
                    at {submitted.hospital}, {submitted.city} is now live on the Emergency
                    Requests board.
                  </p>
                  <div className="mt-4 flex flex-wrap gap-3">
                    <Link to="/emergency-requests" className="btn-secondary px-5 py-2.5 text-xs">
                      View Emergency Requests
                    </Link>
                    <button
                      type="button"
                      onClick={() => setSubmitted(null)}
                      className="btn-ghost text-xs"
                    >
                      Submit another request
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Matching donors */}
            <div>
              <h2 className="flex items-center gap-2 font-display text-xl font-bold text-slate-900">
                <Users className="h-5 w-5 text-red-600" />
                {matches.exact.length > 0
                  ? `Matching Donors Found (${matches.exact.length})`
                  : 'No exact matches in your city yet'}
              </h2>

              {matches.exact.length > 0 ? (
                <>
                  <p className="mt-1 text-sm text-slate-500">
                    Available {submitted.bloodGroup} donors in {submitted.city}. Contact them
                    directly.
                  </p>
                  <div className="mt-5 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                    {matches.exact.map((donor) => (
                      <DonorCard key={donor.id} donor={donor} />
                    ))}
                  </div>
                </>
              ) : (
                <p className="mt-1 max-w-2xl text-sm text-slate-500">
                  No available {submitted.bloodGroup} donors are registered in {submitted.city}{' '}
                  right now. Your request stays visible to everyone on the Emergency Requests
                  board.
                </p>
              )}

              {matches.others.length > 0 && (
                <div className="mt-10">
                  <h3 className="font-display text-base font-bold text-slate-900">
                    Available {submitted.bloodGroup} donors in other cities
                  </h3>
                  <div className="mt-4 grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
                    {matches.others.slice(0, 6).map((donor) => (
                      <DonorCard key={donor.id} donor={donor} />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
