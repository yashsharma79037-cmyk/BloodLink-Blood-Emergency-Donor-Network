import { Link } from 'react-router-dom';
import { Droplet } from 'lucide-react';

export default function About() {
  return (
    <div>
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page py-12">
          <p className="page-eyebrow">About</p>
          <h1 className="page-title">About BloodLink</h1>
        </div>
      </section>

      <section className="container-page py-10">
        <div className="card max-w-3xl space-y-4 p-6 leading-relaxed text-slate-600 sm:p-8">
          <p>
            BloodLink is a college mini project that demonstrates how a community blood and
            emergency donor network could work. People who urgently need blood can post a request,
            and voluntary donors with a matching blood group in the same city are suggested
            instantly.
          </p>
          <p>
            The application is intentionally simple: it runs entirely in the browser, stores demo
            data in localStorage, and uses fictional sample donors and requests. No real personal
            data is collected or shared.
          </p>
          <p className="rounded-xl border border-red-100 bg-red-50 p-4 text-sm text-red-900">
            BloodLink is a demonstration project. Blood donation eligibility, compatibility,
            collection, storage, and transfusion decisions must be handled by qualified healthcare
            professionals and authorized blood banks.
          </p>
          <Link to="/find-donors" className="btn-primary mt-2 inline-flex">
            <Droplet className="h-4 w-4" />
            Explore the donor directory
          </Link>
        </div>
      </section>
    </div>
  );
}
