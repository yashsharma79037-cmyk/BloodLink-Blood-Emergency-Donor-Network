import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Inbox, Plus, Siren } from 'lucide-react';
import EmergencyRequestCard from '../components/EmergencyRequestCard';
import { useApp } from '../context/AppContext';
import { cx, URGENCY_LEVELS } from '../utils/helpers';

const URGENCY_ORDER = { Critical: 0, Urgent: 1, Normal: 2 };

export default function EmergencyRequests() {
  const { requests } = useApp();
  const [urgencyFilter, setUrgencyFilter] = useState('All');

  const totalActive = requests.filter((request) => request.status === 'Active').length;

  const visibleRequests = useMemo(
    () =>
      requests
        .filter((request) => request.status === 'Active')
        .filter((request) => urgencyFilter === 'All' || request.urgency === urgencyFilter)
        .sort(
          (a, b) =>
            URGENCY_ORDER[a.urgency] - URGENCY_ORDER[b.urgency] ||
            new Date(b.createdAt) - new Date(a.createdAt)
        ),
    [requests, urgencyFilter]
  );

  return (
    <div>
      {/* Page header */}
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page flex flex-col gap-6 py-12 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="page-eyebrow flex items-center gap-2">
              <Siren className="h-4 w-4" />
              Live board
            </p>
            <h1 className="page-title">Emergency Requests</h1>
            <p className="mt-3 max-w-2xl text-slate-600">
              {totalActive} active request{totalActive === 1 ? '' : 's'} waiting for donors.
              Critical cases are highlighted in red.
            </p>
          </div>
          <Link to="/request-blood" className="btn-primary shrink-0">
            <Plus className="h-4 w-4" />
            Request Blood
          </Link>
        </div>
      </section>

      <section className="container-page py-10">
        {/* Urgency filter pills */}
        <div className="flex flex-wrap gap-2">
          {['All', ...URGENCY_LEVELS].map((level) => (
            <button
              key={level}
              type="button"
              onClick={() => setUrgencyFilter(level)}
              className={cx(
                'rounded-full border px-4 py-1.5 text-xs font-semibold transition-colors',
                urgencyFilter === level
                  ? 'border-red-600 bg-red-600 text-white'
                  : 'border-slate-300 bg-white text-slate-600 hover:border-red-300 hover:text-red-600'
              )}
            >
              {level}
            </button>
          ))}
        </div>

        {visibleRequests.length > 0 ? (
          <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {visibleRequests.map((request, index) => (
              <div
                key={request.id}
                className="animate-fade-up"
                style={{ animationDelay: `${Math.min(index, 8) * 50}ms` }}
              >
                <EmergencyRequestCard request={request} />
              </div>
            ))}
          </div>
        ) : (
          <div className="card mt-6 flex flex-col items-center gap-3 p-12 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 text-slate-400">
              <Inbox className="h-7 w-7" />
            </span>
            <h2 className="font-display text-lg font-bold text-slate-900">
              No active requests here
            </h2>
            <p className="max-w-sm text-sm text-slate-500">
              There are no{' '}
              {urgencyFilter === 'All' ? '' : `${urgencyFilter.toLowerCase()} `}requests right now.
              Create one and matching donors will be suggested instantly.
            </p>
            <Link to="/request-blood" className="btn-primary mt-2">
              Create Emergency Request
            </Link>
          </div>
        )}
      </section>
    </div>
  );
}
