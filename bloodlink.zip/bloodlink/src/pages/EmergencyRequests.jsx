import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpDown, Inbox, Plus, Siren } from 'lucide-react';
import EmergencyRequestCard from '../components/EmergencyRequestCard';
import { useApp } from '../context/AppContext';
import { BLOOD_GROUPS, cx, URGENCY_LEVELS } from '../utils/helpers';

const URGENCY_ORDER = { Critical: 0, Urgent: 1, Normal: 2 };

const SORT_OPTIONS = [
  { value: 'urgency', label: 'Urgency' },
  { value: 'newest', label: 'Newest first' },
  { value: 'group', label: 'Blood group' },
  { value: 'hospital', label: 'Hospital (A–Z)' },
];

export default function EmergencyRequests() {
  const { requests } = useApp();
  const [urgencyFilter, setUrgencyFilter] = useState('All');
  const [sortBy, setSortBy] = useState('urgency');

  const totalActive = requests.filter((request) => request.status === 'Active').length;

  const visibleRequests = useMemo(() => {
    const list = requests
      .filter((request) => request.status === 'Active')
      .filter((request) => urgencyFilter === 'All' || request.urgency === urgencyFilter);

    switch (sortBy) {
      case 'newest':
        list.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'group':
        list.sort(
          (a, b) =>
            BLOOD_GROUPS.indexOf(a.bloodGroup) - BLOOD_GROUPS.indexOf(b.bloodGroup) ||
            new Date(b.createdAt) - new Date(a.createdAt)
        );
        break;
      case 'hospital':
        list.sort(
          (a, b) =>
            a.hospital.localeCompare(b.hospital) || new Date(b.createdAt) - new Date(a.createdAt)
        );
        break;
      default: // urgency: Critical -> Urgent -> Normal, newest first within each
        list.sort(
          (a, b) =>
            URGENCY_ORDER[a.urgency] - URGENCY_ORDER[b.urgency] ||
            new Date(b.createdAt) - new Date(a.createdAt)
        );
    }
    return list;
  }, [requests, urgencyFilter, sortBy]);

  return (
    <div>
      {/* Page header */}
      <section className="border-b border-slate-200 bg-slate-50">
        <div className="container-page flex flex-col gap-6 py-12 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="page-eyebrow flex items-center gap-2">
              <Siren className="h-4 w-4" />
              Live board
            </p>
            <h1 className="page-title">Emergency Requests</h1>
            <p className="mt-3 max-w-2xl text-slate-600">
              {totalActive} active request{totalActive === 1 ? '' : 's'} waiting for donors.
              Critical cases are highlighted in red.
            </p>
          </div>
          <Link to="/request-blood" className="btn-primary shrink-0">
            <Plus className="h-4 w-4" />
            Request Blood
          </Link>
        </div>
      </section>

      <section className="container-page py-10">
        {/* Urgency filter pills + sort */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-2">
            {['All', ...URGENCY_LEVELS].map((level) => (
              <button
                key={level}
                type="button"
                onClick={() => setUrgencyFilter(level)}
                className={cx(
                  'rounded-full border px-4 py-1.5 text-xs font-semibold transition-colors',
                  urgencyFilter === level
                    ? 'border-red-600 bg-red-600 text-white'
                    : 'border-slate-300 bg-white text-slate-600 hover:border-red-300 hover:text-red-600'
                )}
              >
                {level}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <label
              htmlFor="sort-requests"
              className="flex items-center gap-1.5 text-xs font-semibold text-slate-500"
            >
              <ArrowUpDown className="h-3.5 w-3.5" />
              Sort by
            </label>
            <select
              id="sort-requests"
              value={sortBy}
              onChange={(event) => setSortBy(event.target.value)}
              className="input-field w-auto py-2 text-xs"
            >
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {visibleRequests.length > 0 ? (
          <div className="mt-6 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
            {visibleRequests.map((request, index) => (
              <div
                key={request.id}
                className="animate-fade-up"
                style={{ animationDelay: `${Math.min(index, 8) * 50}ms` }}
              >
                <EmergencyRequestCard request={request} />
              </div>
            ))}
          </div>
        ) : (
          <div className="card mt-6 flex flex-col items-center gap-3 p-12 text-center">
            <span className="flex h-14 w-14 items-center justify-center rounded-full bg-slate-100 text-slate-400">
              <Inbox className="h-7 w-7" />
            </span>
            <h2 className="font-display text-lg font-bold text-slate-900">
              No active requests here
            </h2>
            <p className="max-w-sm text-sm text-slate-500">
              There are no{' '}
              {urgencyFilter === 'All' ? '' : `${urgencyFilter.toLowerCase()} `}requests right now.
              Create one and matching donors will be suggested instantly.
            </p>
            <Link to="/request-blood" className="btn-primary mt-2">
              Create Emergency Request
            </Link>
          </div>
        )}
      </section>
    </div>
  );
}
