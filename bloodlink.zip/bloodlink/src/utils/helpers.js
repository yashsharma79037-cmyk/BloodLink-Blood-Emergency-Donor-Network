// Shared constants and small utility functions used across the app.

export const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const URGENCY_LEVELS = ['Critical', 'Urgent', 'Normal'];

// Tailwind class packs for each urgency level, used by request cards and badges.
export const URGENCY_STYLES = {
  Critical: {
    badge: 'border-red-200 bg-red-100 text-red-700',
    card: 'border-red-300 bg-red-50/40 ring-1 ring-red-100',
    dot: 'bg-red-500',
  },
  Urgent: {
    badge: 'border-amber-200 bg-amber-100 text-amber-700',
    card: 'border-slate-200 bg-white',
    dot: 'bg-amber-500',
  },
  Normal: {
    badge: 'border-sky-200 bg-sky-100 text-sky-700',
    card: 'border-slate-200 bg-white',
    dot: 'bg-sky-500',
  },
};

// Join class names together, skipping falsy values.
export const cx = (...classes) => classes.filter(Boolean).join(' ');

// "4 months ago" style relative time for a date string.
export function timeAgo(dateInput) {
  if (!dateInput) return 'Not available';
  const date = new Date(dateInput);
  if (Number.isNaN(date.getTime())) return 'Not available';

  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return 'Just now';

  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;

  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;

  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} day${days > 1 ? 's' : ''} ago`;

  const months = Math.floor(days / 30);
  if (months < 12) return `${months} month${months > 1 ? 's' : ''} ago`;

  const years = Math.floor(days / 365);
  return `${years} year${years > 1 ? 's' : ''} ago`;
}

// Simple demo matcher: exact blood group + same city (case-insensitive),
// available donors only. `others` holds same-group donors in other cities.
export function findMatchingDonors(donors, bloodGroup, city) {
  const target = (city || '').trim().toLowerCase();
  const available = donors.filter(
    (donor) => donor.available && donor.bloodGroup === bloodGroup
  );
  return {
    exact: available.filter((donor) => donor.city.trim().toLowerCase() === target),
    others: available.filter((donor) => donor.city.trim().toLowerCase() !== target),
  };
}

// Initials for the donor avatar, e.g. "Rahul Patil" -> "RP".
export function initials(name = '') {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0].toUpperCase())
    .join('');
}
