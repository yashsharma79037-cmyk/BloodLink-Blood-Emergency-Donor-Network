import { useState } from 'react';
import { Send } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BLOOD_GROUPS, URGENCY_LEVELS, cx } from '../utils/helpers';

const INITIAL_FORM = {
  patientName: '',
  bloodGroup: '',
  units: '1',
  hospital: '',
  city: '',
  contact: '',
  urgency: 'Urgent',
  message: '',
};

const PHONE_PATTERN = /^[+]?[\d\s-]{10,15}$/;

export default function RequestForm({ onSubmitted }) {
  const { addRequest, toast } = useApp();
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});

  const update = (key) => (event) => {
    const { value } = event.target;
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const validate = () => {
    const next = {};
    if (!form.patientName.trim()) next.patientName = 'Patient name is required.';
    if (!form.bloodGroup) next.bloodGroup = 'Select the required blood group.';

    const units = Number(form.units);
    if (!form.units || Number.isNaN(units) || units < 1 || units > 10) {
      next.units = 'Enter between 1 and 10 units.';
    }

    if (!form.hospital.trim()) next.hospital = 'Hospital name is required.';
    if (!form.city.trim()) next.city = 'City is required.';
    if (!PHONE_PATTERN.test(form.contact.trim())) next.contact = 'Enter a valid contact number.';
    if (!URGENCY_LEVELS.includes(form.urgency)) next.urgency = 'Select an urgency level.';
    return next;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const next = validate();
    if (Object.keys(next).length > 0) {
      setErrors(next);
      toast('Please fix the highlighted fields.', 'error');
      return;
    }

    const request = addRequest({
      patientName: form.patientName.trim(),
      bloodGroup: form.bloodGroup,
      units: Number(form.units),
      hospital: form.hospital.trim(),
      city: form.city.trim(),
      contact: form.contact.trim(),
      urgency: form.urgency,
      message: form.message.trim(),
    });

    toast('Blood request submitted successfully.');
    setForm(INITIAL_FORM);
    onSubmitted(request);
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="card p-6 sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="req-patient" className="form-label">
            Patient name *
          </label>
          <input
            id="req-patient"
            type="text"
            value={form.patientName}
            onChange={update('patientName')}
            placeholder="e.g. Aarav Mehta"
            className={cx('input-field', errors.patientName && 'input-invalid')}
          />
          {errors.patientName && <span className="error-text">{errors.patientName}</span>}
        </div>

        <div>
          <label htmlFor="req-group" className="form-label">
            Blood group required *
          </label>
          <select
            id="req-group"
            value={form.bloodGroup}
            onChange={update('bloodGroup')}
            className={cx('input-field', errors.bloodGroup && 'input-invalid')}
          >
            <option value="">Select blood group</option>
            {BLOOD_GROUPS.map((group) => (
              <option key={group} value={group}>
                {group}
              </option>
            ))}
          </select>
          {errors.bloodGroup && <span className="error-text">{errors.bloodGroup}</span>}
        </div>

        <div>
          <label htmlFor="req-units" className="form-label">
            Number of units *
          </label>
          <input
            id="req-units"
            type="number"
            min="1"
            max="10"
            value={form.units}
            onChange={update('units')}
            className={cx('input-field', errors.units && 'input-invalid')}
          />
          {errors.units && <span className="error-text">{errors.units}</span>}
        </div>

        <div>
          <label htmlFor="req-hospital" className="form-label">
            Hospital name *
          </label>
          <input
            id="req-hospital"
            type="text"
            value={form.hospital}
            onChange={update('hospital')}
            placeholder="e.g. City Care Hospital"
            className={cx('input-field', errors.hospital && 'input-invalid')}
          />
          {errors.hospital && <span className="error-text">{errors.hospital}</span>}
        </div>

        <div>
          <label htmlFor="req-city" className="form-label">
            City *
          </label>
          <input
            id="req-city"
            type="text"
            value={form.city}
            onChange={update('city')}
            placeholder="e.g. Pune"
            className={cx('input-field', errors.city && 'input-invalid')}
          />
          {errors.city && <span className="error-text">{errors.city}</span>}
        </div>

        <div>
          <label htmlFor="req-contact" className="form-label">
            Contact number *
          </label>
          <input
            id="req-contact"
            type="tel"
            value={form.contact}
            onChange={update('contact')}
            placeholder="e.g. +91 98XXX XXXXX"
            className={cx('input-field', errors.contact && 'input-invalid')}
          />
          {errors.contact && <span className="error-text">{errors.contact}</span>}
        </div>

        <div>
          <label htmlFor="req-urgency" className="form-label">
            Urgency level *
          </label>
          <select
            id="req-urgency"
            value={form.urgency}
            onChange={update('urgency')}
            className={cx('input-field', errors.urgency && 'input-invalid')}
          >
            {URGENCY_LEVELS.map((level) => (
              <option key={level} value={level}>
                {level}
              </option>
            ))}
          </select>
          {errors.urgency && <span className="error-text">{errors.urgency}</span>}
        </div>

        <div className="sm:col-span-2">
          <label htmlFor="req-message" className="form-label">
            Additional message
          </label>
          <textarea
            id="req-message"
            rows="3"
            value={form.message}
            onChange={update('message')}
            placeholder="Any extra details donors should know (optional)"
            className="input-field resize-none"
          />
        </div>
      </div>

      <button type="submit" className="btn-primary mt-6 w-full sm:w-auto">
        <Send className="h-4 w-4" />
        Submit Emergency Request
      </button>
      <p className="mt-3 text-xs text-slate-400">
        Demo form — the request is stored only in this browser.
      </p>
    </form>
  );
}
