import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Droplet, Menu, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cx } from '../utils/helpers';

const NAV_LINKS = [
  { to: '/', label: 'Home' },
  { to: '/find-donors', label: 'Find Donors' },
  { to: '/emergency-requests', label: 'Emergency Requests' },
  { to: '/become-donor', label: 'Become a Donor' },
  { to: '/dashboard', label: 'Dashboard' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const { requests } = useApp();
  const navigate = useNavigate();

  const activeCount = requests.filter((request) => request.status === 'Active').length;

  const goToRequestBlood = () => {
    setOpen(false);
    navigate('/request-blood');
  };

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200 bg-white/95 backdrop-blur">
      <nav className="container-page flex h-16 items-center justify-between gap-4">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2.5" aria-label="BloodLink home">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-600 shadow-sm">
            <Droplet className="h-5 w-5 fill-white text-white" />
          </span>
          <span className="font-display text-xl font-bold tracking-tight text-slate-900">
            Blood<span className="text-red-600">Link</span>
          </span>
        </Link>

        {/* Desktop links */}
        <div className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === '/'}
              className={({ isActive }) =>
                cx(
                  'relative rounded-full px-3.5 py-2 text-sm font-medium transition-colors',
                  isActive ? 'bg-red-50 text-red-600' : 'text-slate-600 hover:text-red-600'
                )
              }
            >
              {link.label}
              {link.to === '/emergency-requests' && activeCount > 0 && (
                <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-[1rem] items-center justify-center rounded-full bg-red-600 px-1 text-[10px] font-bold text-white">
                  {activeCount}
                </span>
              )}
            </NavLink>
          ))}
        </div>

        {/* Desktop CTA */}
        <div className="hidden lg:block">
          <button type="button" onClick={goToRequestBlood} className="btn-primary px-5 py-2.5">
            <Droplet className="h-4 w-4" />
            Request Blood
          </button>
        </div>

        {/* Mobile menu toggle */}
        <button
          type="button"
          onClick={() => setOpen((prev) => !prev)}
          className="rounded-lg p-2 text-slate-700 transition hover:bg-slate-100 lg:hidden"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="border-t border-slate-200 bg-white px-4 pb-4 pt-2 lg:hidden">
          <div className="flex flex-col gap-1">
            {NAV_LINKS.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === '/'}
                onClick={() => setOpen(false)}
                className={({ isActive }) =>
                  cx(
                    'flex items-center justify-between rounded-xl px-4 py-3 text-sm font-medium',
                    isActive ? 'bg-red-50 text-red-600' : 'text-slate-700 hover:bg-slate-50'
                  )
                }
              >
                {link.label}
                {link.to === '/emergency-requests' && activeCount > 0 && (
                  <span className="rounded-full bg-red-600 px-2 py-0.5 text-xs font-bold text-white">
                    {activeCount}
                  </span>
                )}
              </NavLink>
            ))}
            <button type="button" onClick={goToRequestBlood} className="btn-primary mt-2 w-full">
              <Droplet className="h-4 w-4" />
              Request Blood
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
