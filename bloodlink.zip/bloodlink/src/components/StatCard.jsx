import { useEffect, useState } from 'react';
import { cx } from '../utils/helpers';

// Animates a number from 0 to `target` with an ease-out curve.
function useCountUp(target, duration = 1200) {
  const [value, setValue] = useState(0);

  useEffect(() => {
    let frame;
    let start;

    const step = (timestamp) => {
      if (start === undefined) start = timestamp;
      const progress = Math.min((timestamp - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(eased * target));
      if (progress < 1) frame = requestAnimationFrame(step);
    };

    frame = requestAnimationFrame(step);
    return () => cancelAnimationFrame(frame);
  }, [target, duration]);

  return value;
}

export default function StatCard({ icon: Icon, value, suffix = '', label, variant = 'solid' }) {
  const count = useCountUp(value);
  const solid = variant === 'solid';

  return (
    <div
      className={cx(
        'rounded-2xl p-6 transition-all duration-200',
        solid
          ? 'bg-white/10 ring-1 ring-white/20 backdrop-blur-sm hover:bg-white/15'
          : 'card card-hover'
      )}
    >
      <span
        className={cx(
          'flex h-11 w-11 items-center justify-center rounded-xl',
          solid ? 'bg-white/15 text-white' : 'bg-red-50 text-red-600'
        )}
      >
        <Icon className="h-5 w-5" />
      </span>
      <p
        className={cx(
          'mt-4 font-display text-3xl font-extrabold tracking-tight sm:text-4xl',
          solid ? 'text-white' : 'text-slate-900'
        )}
      >
        {count.toLocaleString()}
        {suffix}
      </p>
      <p className={cx('mt-1 text-sm font-medium', solid ? 'text-red-100' : 'text-slate-500')}>
        {label}
      </p>
    </div>
  );
}
