import { useState } from 'react';
import {
  Building2,
  CheckCircle2,
  Clock,
  Droplets,
  HeartHandshake,
  MapPin,
  Phone,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cx, timeAgo, URGENCY_STYLES } from '../utils/helpers';

export default function EmergencyRequestCard({ request }) {
  const { toast } = useApp();
  const [responded, setResponded] = useState(false);

  const styles = URGENCY_STYLES[request.urgency] || URGENCY_STYLES.Normal;
  const isCompleted = request.status === 'Completed';
  const isCritical = request.urgency === 'Critical';

  const handleDonate = () => {
    setResponded(true);
    toast('Thank you for stepping up! Please contact the requester directly.');
  };

  return (
    <article className={cx('card flex h-full flex-col p-5', styles.card, isCompleted && 'opacity-75')}>
      {/* Header: urgency line + patient + blood group tile */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-red-600">
            <span className="relative flex h-2 w-2">
              {isCritical && !isCompleted && (
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
              )}
              <span className={cx('relative inline-flex h-2 w-2 rounded-full', styles.dot)} />
            </span>
            {request.urgency === 'Normal' ? 'Blood required' : `${request.urgency} blood required`}
          </p>
          <h3 className="mt-1.5 font-display text-lg font-bold text-slate-900">
            {request.patientName}
          </h3>
        </div>
        <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-red-600 font-display text-base font-extrabold text-white shadow-sm">
          {request.bloodGroup}
        </span>
      </div>

      {/* Details */}
      <div className="mt-4 grid gap-2 text-sm text-slate-600">
        <p className="flex items-center gap-2">
          <Droplets className="h-4 w-4 shrink-0 text-red-500" />
          <span className="font-semibold text-slate-900">
            {request.units} unit{request.units > 1 ? 's' : ''} required
          </span>
        </p>
        <p className="flex items-center gap-2">
          <Building2 className="h-4 w-4 shrink-0 text-slate-400" />
          {request.hospital}
        </p>
        <p className="flex items-center gap-2">
          <MapPin className="h-4 w-4 shrink-0 text-slate-400" />
          {request.city}
        </p>
        <p className="flex items-center gap-2">
          <Clock className="h-4 w-4 shrink-0 text-slate-400" />
          Requested {timeAgo(request.createdAt)}
        </p>
      </div>

      {request.message && (
        <p className="mt-3 rounded-xl bg-slate-50 p-3 text-xs italic leading-relaxed text-slate-500">
          "{request.message}"
        </p>
      )}

      {/* Footer: urgency badge + action */}
      <div className="mt-auto flex items-center justify-between gap-3 pt-4">
        <span className={cx('badge', styles.badge)}>{request.urgency}</span>
        {isCompleted ? (
          <span className="badge border-emerald-200 bg-emerald-50 text-emerald-700">
            <CheckCircle2 className="h-3.5 w-3.5" />
            Completed
          </span>
        ) : responded ? (
          <a
            href={`tel:${request.contact}`}
            className="btn-secondary border-emerald-300 px-4 py-2 text-xs text-emerald-700 hover:border-emerald-400 hover:text-emerald-800"
          >
            <Phone className="h-4 w-4" />
            {request.contact}
          </a>
        ) : (
          <button type="button" onClick={handleDonate} className="btn-primary px-5 py-2.5 text-xs">
            <HeartHandshake className="h-4 w-4" />
            I Can Donate
          </button>
        )}
      </div>
    </article>
  );
}
