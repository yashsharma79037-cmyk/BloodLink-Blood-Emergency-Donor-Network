import { Link } from 'react-router-dom';
import { ArrowRight, Droplet, HeartPulse, Search, Siren } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-white">
      {/* Soft red glow behind the headline */}
      <div
        className="pointer-events-none absolute -top-32 left-1/2 h-96 w-[42rem] -translate-x-1/2 rounded-full bg-red-100/60 blur-3xl"
        aria-hidden="true"
      />

      {/* Signature ECG pulse line running across the hero */}
      <svg
        className="pointer-events-none absolute inset-x-0 top-1/2 hidden w-full text-red-100 md:block"
        viewBox="0 0 1200 100"
        fill="none"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path
          d="M0 50h420l20-28 24 56 20-46 16 18h680"
          stroke="currentColor"
          strokeWidth="2"
        />
      </svg>

      <div className="container-page relative py-20 text-center sm:py-28">
        <span className="inline-flex items-center gap-2 rounded-full border border-red-100 bg-red-50 px-4 py-1.5 text-xs font-semibold text-red-700">
          <HeartPulse className="h-4 w-4" />
          Blood &amp; Emergency Donor Network
        </span>

        <h1 className="mx-auto mt-6 max-w-3xl font-display text-4xl font-extrabold tracking-tight text-slate-900 sm:text-6xl">
          Donate Blood. <span className="text-red-600">Save Lives.</span>
        </h1>

        <p className="mx-auto mt-5 max-w-xl text-lg leading-relaxed text-slate-600">
          Connecting blood donors with people who need help during emergencies.
        </p>

        <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link to="/find-donors" className="btn-primary w-full sm:w-auto">
            <Search className="h-4 w-4" />
            Find a Donor
          </Link>
          <Link to="/request-blood" className="btn-secondary w-full sm:w-auto">
            <Droplet className="h-4 w-4" />
            Request Blood
          </Link>
        </div>

        {/* Emergency callout */}
        <div className="mx-auto mt-10 flex max-w-xl items-center gap-4 rounded-2xl border border-red-200 bg-red-50 p-4 text-left">
          <span className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-600 text-white">
            <span
              className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-red-500"
              aria-hidden="true"
            />
            <Siren className="relative h-5 w-5" />
          </span>
          <p className="text-sm leading-relaxed text-red-900">
            <span className="font-semibold">Need blood urgently?</span> Create an emergency request
            and find matching donors nearby.{' '}
            <Link
              to="/request-blood"
              className="inline-flex items-center gap-1 font-semibold text-red-600 underline-offset-2 hover:underline"
            >
              Create request <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </p>
        </div>
      </div>
    </section>
  );
}
