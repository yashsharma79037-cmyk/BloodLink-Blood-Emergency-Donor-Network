import { ArrowRight } from 'lucide-react';

export default function BloodGroupCard({ group, count, onClick }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={`Find ${group} donors`}
      className="group card card-hover flex flex-col items-center p-6 text-center focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500 focus-visible:ring-offset-2"
    >
      <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-red-50 transition-colors group-hover:bg-red-600">
        <span className="font-display text-xl font-extrabold text-red-600 transition-colors group-hover:text-white">
          {group}
        </span>
      </span>
      <p className="mt-3 text-sm font-semibold text-slate-900">
        {count} donor{count === 1 ? '' : 's'}
      </p>
      <p className="mt-1 flex items-center gap-1 text-xs font-medium text-slate-400 transition-colors group-hover:text-red-600">
        Find donors <ArrowRight className="h-3 w-3" />
      </p>
    </button>
  );
}
