import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { cx } from '../utils/helpers';

const TOAST_STYLES = {
  success: { icon: CheckCircle2, accent: 'border-l-emerald-500', iconColor: 'text-emerald-500' },
  error: { icon: AlertCircle, accent: 'border-l-red-500', iconColor: 'text-red-500' },
  info: { icon: Info, accent: 'border-l-sky-500', iconColor: 'text-sky-500' },
};

export default function ToastContainer() {
  const { toasts, dismissToast } = useApp();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed right-4 top-20 z-[70] flex w-[calc(100vw-2rem)] max-w-sm flex-col gap-3">
      {toasts.map((toastItem) => {
        const style = TOAST_STYLES[toastItem.type] || TOAST_STYLES.info;
        const Icon = style.icon;
        return (
          <div
            key={toastItem.id}
            role="status"
            className={cx(
              'flex animate-toast-in items-start gap-3 rounded-xl border border-l-4 border-slate-200 bg-white p-4 shadow-lg',
              style.accent
            )}
          >
            <Icon className={cx('mt-0.5 h-5 w-5 shrink-0', style.iconColor)} />
            <p className="flex-1 text-sm font-medium text-slate-800">{toastItem.message}</p>
            <button
              type="button"
              onClick={() => dismissToast(toastItem.id)}
              aria-label="Dismiss notification"
              className="rounded-md p-0.5 text-slate-400 transition hover:text-slate-600"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
}
