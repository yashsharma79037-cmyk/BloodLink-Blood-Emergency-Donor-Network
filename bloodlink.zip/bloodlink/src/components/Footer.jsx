import { Link } from 'react-router-dom';
import { Droplet, HeartPulse } from 'lucide-react';

const FOOTER_LINKS = [
  { to: '/about', label: 'About' },
  { to: '/find-donors', label: 'Find Donors' },
  { to: '/emergency-requests', label: 'Emergency Help' },
  { to: '/privacy', label: 'Privacy' },
];

export default function Footer() {
  return (
    <footer className="border-t border-slate-800 bg-slate-900">
      <div className="container-page py-12">
        <div className="flex flex-col gap-10 md:flex-row md:items-start md:justify-between">
          {/* Brand */}
          <div className="max-w-sm">
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-red-600">
                <Droplet className="h-5 w-5 fill-white text-white" />
              </span>
              <span className="font-display text-xl font-bold tracking-tight text-white">
                Blood<span className="text-red-500">Link</span>
              </span>
            </div>
            <p className="mt-3 text-sm font-medium text-slate-300">
              Blood &amp; Emergency Donor Network
            </p>
            <p className="mt-1 text-sm text-slate-400">Connecting donors. Saving lives.</p>
          </div>

          {/* Links */}
          <nav aria-label="Footer" className="flex flex-wrap gap-x-8 gap-y-3">
            {FOOTER_LINKS.map((link) => (
              <Link
                key={link.label}
                to={link.to}
                className="text-sm font-medium text-slate-300 transition-colors hover:text-white"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        {/* Safety disclaimer */}
        <div className="mt-10 rounded-xl border border-slate-800 bg-slate-800/50 p-4">
          <p className="text-xs leading-relaxed text-slate-400">
            <span className="font-semibold text-slate-300">Demo project notice: </span>
            BloodLink is a demonstration project. Blood donation eligibility, compatibility,
            collection, storage, and transfusion decisions must be handled by qualified healthcare
            professionals and authorized blood banks.
          </p>
        </div>

        <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-slate-800 pt-6 text-xs text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} BloodLink · College mini project</p>
          <p className="flex items-center gap-1.5">
            Made with <HeartPulse className="h-3.5 w-3.5 text-red-500" /> for the community
          </p>
        </div>
      </div>
    </footer>
  );
}
