import { useState } from 'react';
import { Calendar, ChevronDown, ChevronUp, Clock, Mail, MapPin, Phone } from 'lucide-react';
import { cx, initials, timeAgo } from '../utils/helpers';

export default function DonorCard({ donor }) {
  const [expanded, setExpanded] = useState(false);
  const [showContact, setShowContact] = useState(false);

  const openContact = () => {
    setShowContact(true);
    setExpanded(true);
  };

  return (
    <article className="card card-hover flex h-full flex-col p-5">
      {/* Name + blood group tile */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-red-100 font-display text-sm font-bold text-red-700">
            {initials(donor.name)}
          </span>
          <div>
            <h3 className="font-display text-base font-bold text-slate-900">{donor.name}</h3>
            <p className="mt-0.5 flex items-center gap-1 text-xs text-slate-500">
              <MapPin className="h-3.5 w-3.5" />
              {donor.area}, {donor.city}
            </p>
          </div>
        </div>
        <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-red-600 font-display text-sm font-extrabold text-white shadow-sm">
          {donor.bloodGroup}
        </span>
      </div>

      {/* Status badges */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <span
          className={cx(
            'badge',
            donor.available
              ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
              : 'border-slate-200 bg-slate-100 text-slate-500'
          )}
        >
          <span
            className={cx(
              'h-1.5 w-1.5 rounded-full',
              donor.available ? 'bg-emerald-500' : 'bg-slate-400'
            )}
          />
          {donor.available ? 'Available' : 'Unavailable'}
        </span>
        <span className="badge border-slate-200 bg-slate-50 text-slate-600">
          <Clock className="h-3 w-3" />
          Last donation: {donor.lastDonation ? timeAgo(donor.lastDonation) : 'First-time donor'}
        </span>
      </div>

      {/* Expandable details */}
      {expanded && (
        <div className="mt-4 space-y-2 rounded-xl bg-slate-50 p-4 text-sm text-slate-600">
          <p className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-slate-400" />
            Age: {donor.age} years
          </p>
          {showContact ? (
            <>
              <a
                href={`tel:${donor.phone}`}
                className="flex items-center gap-2 font-medium text-red-600 hover:underline"
              >
                <Phone className="h-4 w-4" />
                {donor.phone}
              </a>
              {donor.email && (
                <a
                  href={`mailto:${donor.email}`}
                  className="flex items-center gap-2 font-medium text-red-600 hover:underline"
                >
                  <Mail className="h-4 w-4" />
                  {donor.email}
                </a>
              )}
              <p className="text-xs text-slate-400">Demo contact details — sample data only.</p>
            </>
          ) : (
            <p className="text-xs text-slate-400">
              Select "Contact Donor" to view contact details.
            </p>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="mt-auto flex gap-2 pt-4">
        <button
          type="button"
          onClick={() => setExpanded((prev) => !prev)}
          className="btn-secondary flex-1 px-4 py-2.5 text-xs"
        >
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          {expanded ? 'Hide Details' : 'View Details'}
        </button>
        <button
          type="button"
          onClick={openContact}
          className="btn-primary flex-1 px-4 py-2.5 text-xs"
        >
          <Phone className="h-4 w-4" />
          Contact Donor
        </button>
      </div>
    </article>
  );
}
