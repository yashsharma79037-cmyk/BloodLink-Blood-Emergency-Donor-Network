import { useState } from 'react';
import { UserPlus } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { BLOOD_GROUPS, cx } from '../utils/helpers';

const INITIAL_FORM = {
  name: '',
  age: '',
  bloodGroup: '',
  city: '',
  area: '',
  phone: '',
  email: '',
  lastDonation: '',
  available: true,
  eligible: false,
};

const PHONE_PATTERN = /^[+]?[\d\s-]{10,15}$/;
const EMAIL_PATTERN = /^\S+@\S+\.\S+$/;

export default function DonorForm({ onRegistered }) {
  const { addDonor, toast } = useApp();
  const [form, setForm] = useState(INITIAL_FORM);
  const [errors, setErrors] = useState({});

  const update = (key) => (event) => {
    const value = event.target.type === 'checkbox' ? event.target.checked : event.target.value;
    setForm((prev) => ({ ...prev, [key]: value }));
    setErrors((prev) => ({ ...prev, [key]: undefined }));
  };

  const validate = () => {
    const next = {};
    if (form.name.trim().length < 2) next.name = 'Full name is required.';

    const age = Number(form.age);
    if (!form.age || Number.isNaN(age) || age < 18 || age > 65) {
      next.age = 'Age must be between 18 and 65.';
    }

    if (!form.bloodGroup) next.bloodGroup = 'Select your blood group.';
    if (!form.city.trim()) next.city = 'City is required.';
    if (!PHONE_PATTERN.test(form.phone.trim())) next.phone = 'Enter a valid phone number.';
    if (form.email.trim() && !EMAIL_PATTERN.test(form.email.trim())) {
      next.email = 'Enter a valid email address.';
    }
    if (!form.eligible) next.eligible = 'Please confirm your eligibility to continue.';
    return next;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const next = validate();
    if (Object.keys(next).length > 0) {
      setErrors(next);
      toast('Please fix the highlighted fields.', 'error');
      return;
    }

    const donor = addDonor({
      name: form.name.trim(),
      age: Number(form.age),
      bloodGroup: form.bloodGroup,
      city: form.city.trim(),
      area: form.area.trim(),
      phone: form.phone.trim(),
      email: form.email.trim(),
      lastDonation: form.lastDonation || null,
      available: form.available,
    });

    toast('Donor registered successfully.');
    setForm(INITIAL_FORM);
    onRegistered(donor);
  };

  const today = new Date().toISOString().split('T')[0];

  return (
    <form onSubmit={handleSubmit} noValidate className="card p-6 sm:p-8">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="donor-name" className="form-label">
            Full name *
          </label>
          <input
            id="donor-name"
            type="text"
            value={form.name}
            onChange={update('name')}
            placeholder="e.g. Rahul Patil"
            className={cx('input-field', errors.name && 'input-invalid')}
          />
          {errors.name && <span className="error-text">{errors.name}</span>}
        </div>

        <div>
          <label htmlFor="donor-age" className="form-label">
            Age *
          </label>
          <input
            id="donor-age"
            type="number"
            min="18"
            max="65"
            value={form.age}
            onChange={update('age')}
            placeholder="18–65"
            className={cx('input-field', errors.age && 'input-invalid')}
          />
          {errors.age && <span className="error-text">{errors.age}</span>}
        </div>

        <div>
          <label htmlFor="donor-group" className="form-label">
            Blood group *
          </label>
          <select
            id="donor-group"
            value={form.bloodGroup}
            onChange={update('bloodGroup')}
            className={cx('input-field', errors.bloodGroup && 'input-invalid')}
          >
            <option value="">Select blood group</option>
            {BLOOD_GROUPS.map((group) => (
              <option key={group} value={group}>
                {group}
              </option>
            ))}
          </select>
          {errors.bloodGroup && <span className="error-text">{errors.bloodGroup}</span>}
        </div>

        <div>
          <label htmlFor="donor-city" className="form-label">
            City *
          </label>
          <input
            id="donor-city"
            type="text"
            value={form.city}
            onChange={update('city')}
            placeholder="e.g. Pune"
            className={cx('input-field', errors.city && 'input-invalid')}
          />
          {errors.city && <span className="error-text">{errors.city}</span>}
        </div>

        <div>
          <label htmlFor="donor-area" className="form-label">
            Area
          </label>
          <input
            id="donor-area"
            type="text"
            value={form.area}
            onChange={update('area')}
            placeholder="e.g. Shivajinagar"
            className="input-field"
          />
        </div>

        <div>
          <label htmlFor="donor-phone" className="form-label">
            Phone number *
          </label>
          <input
            id="donor-phone"
            type="tel"
            value={form.phone}
            onChange={update('phone')}
            placeholder="e.g. +91 98XXX XXXXX"
            className={cx('input-field', errors.phone && 'input-invalid')}
          />
          {errors.phone && <span className="error-text">{errors.phone}</span>}
        </div>

        <div>
          <label htmlFor="donor-email" className="form-label">
            Email
          </label>
          <input
            id="donor-email"
            type="email"
            value={form.email}
            onChange={update('email')}
            placeholder="you@example.com"
            className={cx('input-field', errors.email && 'input-invalid')}
          />
          {errors.email && <span className="error-text">{errors.email}</span>}
        </div>

        <div>
          <label htmlFor="donor-last-donation" className="form-label">
            Last donation date
          </label>
          <input
            id="donor-last-donation"
            type="date"
            max={today}
            value={form.lastDonation}
            onChange={update('lastDonation')}
            className="input-field"
          />
        </div>
      </div>

      {/* Availability + eligibility confirmations */}
      <div className="mt-6 space-y-3">
        <label className="flex items-start gap-3 rounded-xl border border-slate-200 bg-slate-50 p-4">
          <input
            type="checkbox"
            checked={form.available}
            onChange={update('available')}
            className="mt-0.5 h-4 w-4 rounded border-slate-300 accent-red-600"
          />
          <span className="text-sm text-slate-600">
            I am currently <span className="font-semibold text-slate-800">available to donate</span>{' '}
            and okay with being contacted for matching requests.
          </span>
        </label>

        <label
          className={cx(
            'flex items-start gap-3 rounded-xl border p-4',
            errors.eligible ? 'border-red-300 bg-red-50/50' : 'border-slate-200 bg-slate-50'
          )}
        >
          <input
            type="checkbox"
            checked={form.eligible}
            onChange={update('eligible')}
            className="mt-0.5 h-4 w-4 rounded border-slate-300 accent-red-600"
          />
          <span className="text-sm text-slate-600">
            I confirm that I meet the applicable blood-donation eligibility requirements. *
            <span className="mt-1 block text-xs text-slate-400">
              Final eligibility screening is always done by qualified healthcare professionals at
              the time of donation.
            </span>
          </span>
        </label>
        {errors.eligible && <span className="error-text">{errors.eligible}</span>}
      </div>

      <button type="submit" className="btn-primary mt-6 w-full sm:w-auto">
        <UserPlus className="h-4 w-4" />
        Register as Donor
      </button>
      <p className="mt-3 text-xs text-slate-400">
        Demo form — your details are stored only in this browser.
      </p>
    </form>
  );
}
