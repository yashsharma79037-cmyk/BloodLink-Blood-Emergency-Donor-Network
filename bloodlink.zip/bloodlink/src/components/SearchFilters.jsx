import { Filter, RotateCcw, Search } from 'lucide-react';
import { BLOOD_GROUPS } from '../utils/helpers';

export default function SearchFilters({ filters, onChange, onSearch, onReset, cities }) {
  const update = (key) => (event) => onChange({ ...filters, [key]: event.target.value });

  const handleSubmit = (event) => {
    event.preventDefault();
    onSearch();
  };

  return (
    <form onSubmit={handleSubmit} className="card p-5 sm:p-6">
      <p className="flex items-center gap-2 text-sm font-semibold text-slate-900">
        <Filter className="h-4 w-4 text-red-600" />
        Filter donors
      </p>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <label htmlFor="filter-group" className="form-label">
            Blood group
          </label>
          <select
            id="filter-group"
            value={filters.group}
            onChange={update('group')}
            className="input-field"
          >
            <option value="All">All groups</option>
            {BLOOD_GROUPS.map((group) => (
              <option key={group} value={group}>
                {group}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="filter-city" className="form-label">
            City
          </label>
          <select
            id="filter-city"
            value={filters.city}
            onChange={update('city')}
            className="input-field"
          >
            <option value="All">All cities</option>
            {cities.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="filter-availability" className="form-label">
            Availability
          </label>
          <select
            id="filter-availability"
            value={filters.availability}
            onChange={update('availability')}
            className="input-field"
          >
            <option value="All">All donors</option>
            <option value="Available">Available</option>
            <option value="Unavailable">Unavailable</option>
          </select>
        </div>

        <div className="flex items-end gap-2">
          <button type="submit" className="btn-primary flex-1 px-4">
            <Search className="h-4 w-4" />
            Find Donors
          </button>
          <button
            type="button"
            onClick={onReset}
            className="btn-secondary px-3.5"
            aria-label="Reset filters"
            title="Reset filters"
          >
            <RotateCcw className="h-4 w-4" />
          </button>
        </div>
      </div>
    </form>
  );
}
