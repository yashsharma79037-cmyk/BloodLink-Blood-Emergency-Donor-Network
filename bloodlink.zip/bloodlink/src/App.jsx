import { Route, Routes } from 'react-router-dom';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import ScrollToTop from './components/ScrollToTop';
import ToastContainer from './components/Toast';
import About from './pages/About';
import BecomeDonor from './pages/BecomeDonor';
import Dashboard from './pages/Dashboard';
import EmergencyRequests from './pages/EmergencyRequests';
import FindDonors from './pages/FindDonors';
import Home from './pages/Home';
import Privacy from './pages/Privacy';
import RequestBlood from './pages/RequestBlood';

export default function App() {
  return (
    <div className="flex min-h-screen flex-col bg-white">
      <ScrollToTop />
      <Navbar />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/find-donors" element={<FindDonors />} />
          <Route path="/emergency-requests" element={<EmergencyRequests />} />
          <Route path="/request-blood" element={<RequestBlood />} />
          <Route path="/become-donor" element={<BecomeDonor />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/about" element={<About />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="*" element={<Home />} />
        </Routes>
      </main>
      <Footer />
      <ToastContainer />
    </div>
  );
}
