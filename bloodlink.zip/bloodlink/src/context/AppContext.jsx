import { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { sampleDonors, sampleRequests } from '../data/sampleData';

const DONORS_KEY = 'bloodlink_donors';
const REQUESTS_KEY = 'bloodlink_requests';

const AppContext = createContext(null);

// Read a key from localStorage, falling back to sample data on first run.
function load(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : [...fallback];
  } catch {
    return [...fallback];
  }
}

let toastCounter = 0;

export function AppProvider({ children }) {
  const [donors, setDonors] = useState(() => load(DONORS_KEY, sampleDonors));
  const [requests, setRequests] = useState(() => load(REQUESTS_KEY, sampleRequests));
  const [toasts, setToasts] = useState([]);

  // Persist to localStorage so data survives page refreshes.
  useEffect(() => {
    localStorage.setItem(DONORS_KEY, JSON.stringify(donors));
  }, [donors]);

  useEffect(() => {
    localStorage.setItem(REQUESTS_KEY, JSON.stringify(requests));
  }, [requests]);

  const dismissToast = useCallback((id) => {
    setToasts((prev) => prev.filter((toastItem) => toastItem.id !== id));
  }, []);

  // Show a small notification. type: 'success' | 'error' | 'info'
  const toast = useCallback(
    (message, type = 'success') => {
      toastCounter += 1;
      const id = toastCounter;
      setToasts((prev) => [...prev, { id, message, type }]);
      window.setTimeout(() => dismissToast(id), 4200);
    },
    [dismissToast]
  );

  const addDonor = useCallback((donor) => {
    const newDonor = { ...donor, id: `d-${Date.now()}` };
    setDonors((prev) => [newDonor, ...prev]);
    return newDonor;
  }, []);

  const addRequest = useCallback((request) => {
    const newRequest = {
      ...request,
      id: `r-${Date.now()}`,
      status: 'Active',
      createdAt: new Date().toISOString(),
    };
    setRequests((prev) => [newRequest, ...prev]);
    return newRequest;
  }, []);

  const markRequestCompleted = useCallback((id) => {
    setRequests((prev) =>
      prev.map((request) => (request.id === id ? { ...request, status: 'Completed' } : request))
    );
  }, []);

  const resetDemoData = useCallback(() => {
    setDonors([...sampleDonors]);
    setRequests([...sampleRequests]);
  }, []);

  const value = {
    donors,
    requests,
    toasts,
    toast,
    dismissToast,
    addDonor,
    addRequest,
    markRequestCompleted,
    resetDemoData,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used inside <AppProvider>');
  return context;
}
